For Investor Review – Prepared by RealSteel S Corporation, 2025
=================================================================

Included Files
--------------
1) RealSteel_Investor_Presentation.html
2) RealSteel_Business_Plan.pdf
3) RealSteel_Business_Plan_Financials.pdf
4) RealSteel_Business_Plan_Financials_WithCharts.pdf
5) RealSteel_Investor_Summary.pdf
6) RealSteel_Investor_Presentation.pdf
7) RealSteel_Business_Plan.md

How to Publish on Google Drive
------------------------------
1) Upload ALL files from this folder into the SAME Google Drive folder.
2) Right-click the folder → Get link → Change to "Anyone with link" → Viewer.
3) Share the link with investors.

Connect with Us
---------------
🌐 https://www.realsteelframes.com
✉️ john@hupla.com
📞 +1-702-785-8481

Version: 1.0 – October 2025
Last updated: October 2025
